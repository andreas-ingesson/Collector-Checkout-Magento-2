<?php

namespace Collector\Iframe\Controller\Index;

class Index extends \Magento\Checkout\Controller\Index\Index
{
}
