<?php

namespace Collector\Base\Logger;

class Collector extends \Monolog\Logger
{
}
