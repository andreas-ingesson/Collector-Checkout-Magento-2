<?php

namespace Collector\Base\Model;

class Session extends \Magento\Framework\Session\SessionManager
{

    const B2B = 'b2b';
    const B2C = 'b2c';
}
